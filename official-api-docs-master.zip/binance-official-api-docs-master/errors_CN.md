文档被迁移到[https://github.com/binance/binance-spot-api-docs/blob/master/errors_CN.md](https://github.com/binance/binance-spot-api-docs/blob/master/errors_CN.md)
