文档被迁移到[https://github.com/binance/binance-spot-api-docs/blob/master/web-socket-streams_CN.md](https://github.com/binance/binance-spot-api-docs/blob/master/web-socket-streams_CN.md)
