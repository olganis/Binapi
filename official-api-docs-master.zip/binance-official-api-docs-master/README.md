## The Binance API documentation on Github has been moved to our official company repository:

[https://github.com/binance/binance-spot-api-docs](https://github.com/binance/binance-spot-api-docs)
