This has been moved to [https://github.com/binance/binance-spot-api-docs/blob/master/CHANGELOG.md](https://github.com/binance/binance-spot-api-docs/blob/master/CHANGELOG.md)
