## 币安的API现已迁移到新的官方Github账号下

[https://github.com/binance/binance-spot-api-docs](https://github.com/binance/binance-spot-api-docs)
